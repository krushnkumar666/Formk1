from django.db import models
import datetime
# Create your models here.
class User(models.Model):
    name=models.CharField(max_length=70)
    DOB=models.DateField(null=True)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=11)

