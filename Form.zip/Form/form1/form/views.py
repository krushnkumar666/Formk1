from django.shortcuts import render
from .forms import StudentRegistration
from .models import User

# Create your views here.
def add_show(request):
    if request.method=='POST':
        fm=StudentRegistration(request.POST)
        if fm.is_valid():
            nm=fm.cleaned_data['name']
            DB=fm.cleaned_data['DOB']
            em=fm.cleaned_data['email']
            ph=fm.cleaned_data['phone']
            reg=User(name=nm,DOB=DB,email=em,phone=ph)
            reg.save()
            fm=StudentRegistration()
    else:
        fm=StudentRegistration()
        User.objects.all()
    return render(request,'form/addandshow.html',{'form':fm})